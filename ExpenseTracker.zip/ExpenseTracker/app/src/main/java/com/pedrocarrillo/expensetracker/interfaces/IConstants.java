package com.pedrocarrillo.expensetracker.interfaces;

/**
 * Created by pcarrillo on 16/10/2015.
 */
public interface IConstants {
    String IS_ACTION_MODE_ACTIVATED = "_action_mode_key";
    String TAB_SELECTED_POS_KEY = "_tab_selected_pos_key";
    String TAG_SELECTED_ITEMS = "_selected_items";
    String BROADCAST_UPDATE_EXPENSES = "_update_expenses_broadcast";
}
