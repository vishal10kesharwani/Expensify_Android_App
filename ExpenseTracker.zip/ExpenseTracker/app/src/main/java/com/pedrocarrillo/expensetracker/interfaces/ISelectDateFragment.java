package com.pedrocarrillo.expensetracker.interfaces;

/**
 * Created by pcarrillo on 13/10/2015.
 */
public interface ISelectDateFragment {
    void updateData();
}
